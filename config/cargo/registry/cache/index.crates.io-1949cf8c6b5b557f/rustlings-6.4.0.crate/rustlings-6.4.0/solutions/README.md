# Official Rustlings solutions

Before you finish an exercise, its solution file will only contain an empty `main` function.
The content of this file will be automatically replaced by the actual solution once you finish the exercise.

Note that these solutions are often only _one possibility_ to solve an exercise.
