fn main() {
    // TODO: Fix the code to print "Hello world!".
    printline!("Hello world!");
}
