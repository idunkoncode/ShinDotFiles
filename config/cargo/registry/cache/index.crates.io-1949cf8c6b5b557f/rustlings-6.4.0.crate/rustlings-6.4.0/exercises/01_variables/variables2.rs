fn main() {
    // TODO: Change the line below to fix the compiler error.
    let x;

    if x == 10 {
        println!("x is ten!");
    } else {
        println!("x is not ten!");
    }
}
