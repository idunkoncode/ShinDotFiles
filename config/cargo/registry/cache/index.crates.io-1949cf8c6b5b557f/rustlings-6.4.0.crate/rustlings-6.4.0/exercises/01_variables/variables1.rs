fn main() {
    // TODO: Add the missing keyword.
    x = 5;

    println!("x has the value {x}");
}
